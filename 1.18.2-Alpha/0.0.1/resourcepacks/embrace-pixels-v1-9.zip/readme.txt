Paste this .zip to your resource pack folder

Thanks for downloading my pack :)

In order to use the resource pack, you will need to use any LabPBR supported shaders, although I highly recommend BSL
I have provided you my settings for BSL shaders in the other .txt file - They mostly keep the vanilla look of the game
You can copy and paste it to your shader pack folder


You are free to edit this pack, but make sure to show me your work :)

If you have ANY questions or maybe need help with set up, please contact me through discord
Mwti#9705

enjoy
